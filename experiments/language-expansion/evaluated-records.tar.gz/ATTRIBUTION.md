# Text attribution and licenses

This archive includes normalized adaptations, not a relicensing of the source texts.

- Old Czech: Karel Kučera and Martin Stluka (2011), DIAKORP v5, Charles University; distributed by Eva Pettersson and Beáta Megyesi, HistCorp (2018). https://zenodo.org/records/10013189 ; https://sprakbanken-clarin.lingfil.uu.se/histcorp/readme/czech-readme-diakorp . CC BY-NC-SA 4.0: https://creativecommons.org/licenses/by-nc-sa/4.0/ . Czech text derivatives in partitions.json and evaluator-only/answers.json retain this license.
- Old Occitan: Marinus Wiedner (ed.), COMETA v1 (2025), https://zenodo.org/records/15300719 . CC BY 4.0: https://creativecommons.org/licenses/by/4.0/ . Occitan text derivatives retain this license.
- Changes: removed metadata/omission markers, joined explicit Occitan line hyphenation, removed one editorial heading, normalized historical glyphs/accents to the fixed cipher alphabet, removed overlapping chunks, selected/truncated equal-letter excerpts, removed spaces for character models. Specific source-work IDs remain attached to every row.
- Six reused languages: original author, revision, download and license records are in experiments/language-sources.json, experiments/standard-decipherment/sources.json and experiments/language-coverage/sources.json in the repository. Broad Latin uses LLCT (Korkiakangas, Cecchini, Passarotti), broad German ReM 2.1, both CC BY-SA 4.0; Catalan HisCat (Pujol i Campeny and Meelen), CC BY 4.0. The prior language-coverage archive includes supporting metadata. Reusing their normalized inputs does not change their licenses.
- Naibbe generator: Michael A. Greshko (2025), original license and pinned source recorded in earlier freezes. Generated ciphertext and reconstruction records are research outputs.

Keep this attribution and the linked source manifests with redistributed text derivatives. Discovery downloads not used by the study are excluded from the archive.
